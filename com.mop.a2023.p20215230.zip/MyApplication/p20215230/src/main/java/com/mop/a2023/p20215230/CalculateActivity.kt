package com.mop.a2023.p20215230

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Stack
import kotlin.math.round
import java.math.BigDecimal
import java.math.RoundingMode
class CalculateActivity : AppCompatActivity() {
    lateinit var textOutput : TextView //아웃풋할 내용 보여줄 것
    lateinit var textInput : TextView //인풋한 내용을 실제 계산식을 작성하기 위해 따로 선언한 변수
    lateinit var textInputView : TextView //인풋한 내용 보여줄 것
    lateinit var measureView : TextView //약수 구해서 보여줄 뷰
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculate)

        textOutput = findViewById(R.id.output)
        textInput = findViewById(R.id.input)
        textInputView = findViewById(R.id.inputView)
        measureView = findViewById(R.id.measureCalculate)

        for (i in 1..18) { //기존 계산기 set에서 사용하지 않는 버튼을 눌렀을 시에 toast창이 뜨도록 만들었음
            //총 사용하지 않는 버튼이 18개인데, for문을 돌려 중복되는 코드를 줄이고자 함
            val notApplyBtn = findViewById<Button>(resources.getIdentifier("notApplyBtn$i", "id", packageName))
            notApplyBtn?.setOnClickListener { //세로일 때 가로할 때 생기는 버튼들이 null로 받아지기 때문에 ?추가 필요함
                Toast.makeText(this, "현재 지원하지 않는 기능입니다.", Toast.LENGTH_SHORT).show()
            }
        }

    }

    fun buttonClicked(view: View) { //모든 버튼이 눌렀을 때 각각의 함수로의 이동은 이 함수를 통함
        //그렇기 때문에 이 함수만 public으로 선언함
        when (view.id) {
            R.id.zero -> numberButtonClicked("0")
            R.id.one -> numberButtonClicked("1")
            R.id.two -> numberButtonClicked("2")
            R.id.three -> numberButtonClicked("3")
            R.id.four -> numberButtonClicked("4")
            R.id.five -> numberButtonClicked("5")
            R.id.six -> numberButtonClicked("6")
            R.id.seven -> numberButtonClicked("7")
            R.id.eight -> numberButtonClicked("8")
            R.id.nine -> numberButtonClicked("9")
            R.id.dot -> numberButtonClicked(".")

            R.id.division -> operatorButtonClicked("/")
            R.id.plus -> operatorButtonClicked("+")
            R.id.sub -> operatorButtonClicked("-")
            R.id.multi -> operatorButtonClicked("*")

            R.id.C -> clearButtonClicked()
            R.id.back -> backButtonClicked()
            R.id.equal -> outputButtonClicked()
            R.id.measure -> measureClicked()
        }
    }
    private fun measureClicked(){ //이건 추가기능을 위한 함수임
        //output의 숫자의 약수를 모두 구해서 보여주는 함수임
        val str = textOutput?.text.toString() //output 숫자가 널일 수도 있으므로 ?을 넣음
        if(str == "") { measureView.setText("'=' 버튼을 누르고 다시 실행해 보세요!"); return;}
        //만약 아무 값도 없었을 경우에는 화면에 텍스트가 뜨도록 구현하여 사용자의 이해를 도움
        Log.d("check", "${str}") //str값을 확인하기 위해 log를 띄움
        if( "." in str){ //콤마가 있는지 없는지로 정수와 실수를 구분하고자 하였음
            measureView.setText("정수가 아닌 수는 약수를 구할 수 없습니다.") //만약 double일 경우에는 이와 같은 문구를 화면에 띄움
        }
        else { //else에서는 str이 정수일 때 약수를 계산해서 화면에 띄울 문구를 만드는 코드가 작성되어 있음
            val number = str.toInt()
            val divisors = mutableListOf<Int>() //약수들이 들어갈 list

            for (i in 1..number) { //for문을 통해 약수를 구하고자 함
                if (number % i == 0) {
                    divisors.add(i)
                }
            }

            measureView.setText("${number}의 약수 : ") //약수를 구한다음 화면의 보여질 글을 작성하는 과정임
            for(i in 0..divisors.size-1){
                if(i == divisors.size-1){
                    measureView.append("${divisors[i]}")
                }
                else {
                    measureView.append("${divisors[i]}, ")
                }
            }
        }
    }
    private fun clearButtonClicked(){ //해당 함수는 "C" 버튼을 눌렀을 때 동작할 함수임
        //"C"를 눌렀을 때 모든 text 값들이 초기화되도록 구현함
        textInput.setText("")
        textOutput.setHint("0")
        textOutput.setText(null)
        textInputView.setText("")
        measureView.setText("")
    }
    private fun backButtonClicked(){ //해당 함수는 "back" 이미지 버튼을 눌렀을 때 동작할 함수임
        //text1은 화면에 뜨진 않지만 실제 계산을 위한 변수이고 text2는 화면에 뜨는 계산을 위한 변수임
        val text1 = textInput.text?.toString()//null exception을 피하기 위해 ? 추가
        val text2 = textInputView.text?.toString()//null exception을 피하기 위해 ? 추가

        if (text1 != "") {
            val modifiedText1 = text1?.substring(0, text1.length - 1) //맨 뒤 글자를 제거하여
            textInput.setText(modifiedText1) //다시 textInput에 저장
            val modifiedText2 = text2?.substring(0, text2.length - 1) //textInputView도 마찬가지임
            textInputView.setText(modifiedText2)
        }
    }

    private fun outputButtonClicked(){ //"="버튼을 눌렀을 때 동작할 함수임
        if(textInput.text.toString() == "") { return } //만약 input한 내용이 아무것도 없다면 이 함수를 바로 종료하도록 해서 오류를 막음
        val result = resultPrint(organize()); //이 함수의 자식 함수로는 resultPrint와 orgaize가 있는데, orgaize()로 중위식 문자열을 후위식으로 변경해주고, resultPrint()는 이 식을 계산하는 역할을 함
        val strippedValue = result?.stripTrailingZeros() //result가 BigDecimal자료형인데, 소수점 아래 숫자가 00000으로 뜰 경우 소수점 아래 숫자들을 지워 화면에 띄우기 위해 stripTrailingZeros()함수를 사용하여 소수점 아래 숫자가 0인지 아닌지 확인함
        if(strippedValue?.scale()!! <= 0){ //정수일 경우
            val returnOne = round(result.toDouble()) //1차적으로 result를 double형으로 바꾼다음 반올림하였고,
            val returnTwo = returnOne.toInt().toString() //2차적으로 이 반올림한 숫자를 int로 바꾼다음 string으로 바꿔줬음
            textOutput.setText(returnTwo)//이렇게 바뀐 값을 output으로 화면에 띄우고자 함
            Log.d("check", "확인 : ${returnOne}, ${returnTwo}") //이건 제대로 실행됐는지 확인하는 코드임
        }
        else if(result != null){ //실수일 경우
            textOutput.setText(result.toString()); //string 자료형으로만 바꿔서 보여주도록 함
        } else {
            return
        }
    }
    private fun checkLastText() : Int?{ //textInput의 맨 뒷글자가 .이면 0을 num이면 1을 operator면 2를 공백이면 3을 return해주는 함수
        val textInputToString : String = textInput?.text.toString()

        if (textInputToString.isNotEmpty()) {
            val lastChar : Char = textInputToString[textInputToString.length - 1]
            when {
                lastChar.equals('.') -> { //.일 경우
                    return 0;
                }
                lastChar.isDigit() -> { //숫자일 경우
                    return 1;
                }
                lastChar.isWhitespace() -> { //공백일 경우
                    return 3;
                }
                else -> { //연산자일 경우
                    return 2;
                }
            }
        } else {
            return null; //첫번째 입력일 경우
        }
    }
    private fun numberButtonClicked(number : String) { //숫자버튼과 .을 눌렀을 때 작동하는 함수
        var checkedLast = checkLastText()
        if(checkedLast==3){ //back버튼을 눌러 맨 뒷글자가 공백일 경우 처리해줌
            backButtonClicked()
        }
        checkedLast = checkLastText() //공백제거한 후 다시 확인
        if(number == "."){ //.이 들어왔을 때 처리
            val wordsArray = textInput.text.toString().split(" ").toTypedArray()

            // 배열의 마지막 항목에 "."이 존재하는지 확인
            val lastWord = wordsArray.lastOrNull()
            val containsDot = lastWord?.contains('.') ?: false
            if(containsDot) {
                return; //숫자에 이미 소숫점을 넣었는데 또 입력했을 경우를 위한 예외처리
            }

            if((checkedLast== null || checkedLast == 2)){ //연산자 뒤에 바로 .이 오거나 첫 번째 입력이 .일 경우
                textInput.append(" 0") //공백 추가 후 0 넣기
                textInputView.append(" 0")
            }
        }
        else { //숫자가 들어왔을 경우 처리
            if (checkedLast == 2) { //연산자일 경우 띄어쓰기 해주도록
                textInput.append(" ")
                textInputView.append(" ")
            }

        }

        textInput.append(number)
        textInputView.append(number)

    }

    private fun operatorButtonClicked(operator : String){ //연산자 버튼을 눌렀을 때 작동할 함수
        var checkedLast = checkLastText()
        if(checkedLast==3){ //back버튼을 눌러 맨 뒷글자가 공백일 경우 처리해줌
            backButtonClicked()
        }
        val visibleOperatorOne = when (operator) { //여기서 실제 계산할 때는 *와 /와 같은 연산자가 쓰이는데, 화면에 보이는 버튼은 x와 ÷이므로 이걸 바꿔서 textInputView에 저장하고자 함
            "+" -> "+"
            "-" -> "-"
            "*" -> "×"
            else -> "÷"
        }
        checkedLast = checkLastText() //공백제거한 후 다시 확인
        if(checkedLast == 2) { //이전에 작성한게 연산자였으면 새로 입력한 연산자로 바뀌도록 수정
            val stringBuilder1 = StringBuilder(textInput.text.toString())
            //operator를 string으로 받기 때문에 0번째 인덱스인 값을 가져온다고해서 char값으로 가져올 수 있도록
            stringBuilder1.setCharAt(stringBuilder1.length - 1, operator.get(0));
            val stringBuilder2 = StringBuilder(textInput.text.toString())
            //operator를 string으로 받기 때문에 0번째 인덱스인 값을 가져온다고해서 char값으로 가져올 수 있도록
            stringBuilder2.setCharAt(stringBuilder2.length - 1, visibleOperatorOne.get(0));

            //////여기 visibleOperator 추가
            textInput.text = stringBuilder1
            textInputView.text = stringBuilder2
        }
        else if(checkedLast == 1) { //이전에 작성한게 숫자였으면 공백 만들어주고 연산자 넣기
            textInput.append(" "+operator)
            textInputView.append(" "+visibleOperatorOne)
        }
    }

    private fun organize(): Array<String?>? { //중위식 문자열을 후위식 표현으로 바꿔줌
        val s = textInput.text.toString()
        val regex = "(?<=[-+*/()])|(?=[-+*/()])".toRegex() //그냥 toregex를 사용하면 "."도 포함하여 split를 하므로 따로 지정해줌
        val str = s.split(regex).filter { it.isNotEmpty() }.toTypedArray() //위에 선언한 regex를 기준으로 string을 나눠 배열로 저장함
        val sb = ArrayList<String>()
        val stack = Stack<String>() //stack을 사용하여 중위식 -> 후위식 표현으로 바꿔줄거임
        for (i in str.indices) { //str의 인덱스 하나하나에 접근하여
            val now = str[i]
            when (now) {
                "+", "-", "*", "/" -> { //연산자일 경우에는
                    while (!stack.isEmpty() && priority(stack.peek()) >= priority(now)) { //스택에서 연산자를 꺼내 현재 연산자보다 우선순위가 높은지 확인하고
                        sb.add(stack.pop()) //sb에 순서대로 저장하다가
                    }
                    stack.push(now) //우선순위에 맞게 현재 값을 저장하고
                }

                else -> sb.add(now) //현재 값을 sb에도 저장하여 for문이 다 돌면 후위식으로 표현 완료
            }
        }
        while (!stack.isEmpty()) { //위의 작업이 끝나고 스택에 남아있는 값을 sb에 추가함
            sb.add(stack.pop())
        }
        val result = arrayOfNulls<String>(sb.size) //위의 작업을 모두 끝내고 result array에 저장
        for (i in sb.indices) {
            result[i] = sb[i]
        }
        return result
    }

    private fun priority(operator: String): Int { //우선순위 부여를 위한 함수
        //방근 organize()함수에서 실행했던 우선순위 확인을 위한 함수임
        if (operator == "+" || operator == "-") {
            return 1
        } else if (operator == "*" || operator == "/") {
            return 2
        }
        return -1
    }

    private fun resultPrint(str: Array<String?>?): BigDecimal? { //후위식을 넣으면 계산해주는 함수
        Log.d("check","함수가 실행되는 건 문제가 없는지 확인")
        val stack = Stack<BigDecimal>() //값이 커지면 double 자료형일 경우에는 부동소수점 문제가 발생하여 bigdecimal 자료형을 사용해 봄
        //위의 stack에 하나하나 값을 계산해서 넣어줄 거임
        if(str != null) {
            for (x in str) { //array 각 인덱스에 접근
                if (x != "+" && x != "-" && x != "*" && x != "/" && x != " ") { //연산자가 아닐 경우에는
                    val xBefore = x?.replace(" ","") //띄어쓰기를 업애고
                    stack.push(xBefore?.toBigDecimalOrNull()) //stack에 숫자만 저장함
                    Log.d("check",x+"가 제대로 뜨지 않는 문제 해결")
                } else { //연산자일 경우에는
                    val a = stack.pop() //스택에 저장된 숫자 두개 씩 꺼내 해당 연산자로 계산해주고 stack에 다시 저장
                    val b = stack.pop()
                    when (x) {
                        "+" -> stack.push(b + a)
                        "-" -> stack.push(b - a)
                        "*" -> stack.push(b.multiply(a).setScale(5, RoundingMode.HALF_UP))
                        //숫자가 너무 커지면 정밀도 문제가 생기므로 소수점 다섯자리에 반올림할 수있도록 함
                        "/" -> stack.push(b.divide(a, 5, RoundingMode.HALF_UP)) //위와 마찬가지
                    }
                }
            }
        }
        return stack.pop() //stack에 마지막으로 남은 값이 최종계산 결과임
    }

}